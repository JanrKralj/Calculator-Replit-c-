#include <iostream>
#include <math.h>
#include <string>
#include <array>

static double number1;
static double number2;
static double result;
static char operatorCharacter;


using namespace std;

int main() 
{
  std::cout << "Hello World!\n" << endl;

  cout << "Welcome to the calculator!" << endl;

  cout << "Enter a number: ";
  cin >> number1;

  cout << "Enter an operator: ";
  cin >> operatorCharacter;

  cout << "Enter another number: ";
  cin >> number2;

  cout << "Your syntax of the following equation is: ";
  cout << number1 << " " << operatorCharacter << " " << number2 << " " << '=' << " " << result;

  if(operatorCharacter == '+') 
  {
    result = number1 += number2;
    cout << result << endl;
  } 
  else if(operatorCharacter == '-') 
  {
    result =  number1 -= number2;
    cout << result << endl;
  }
  else if(operatorCharacter == '*') 
  {
    result = number1 *= number2;
    cout << result << endl;
  }
  else if(operatorCharacter == '/') 
  {
    result = number1 / number2;
    cout << result << endl;
  }
  else 
  {
      cout << "Incorrect syntax!" << endl;
  }
}